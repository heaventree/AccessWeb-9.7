// Node.js process polyfill for browser environment
import process from 'process/browser';
window.process = process;