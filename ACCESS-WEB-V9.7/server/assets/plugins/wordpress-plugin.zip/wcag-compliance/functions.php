<?php

add_action('compliance_scheduled_hook', 'compliance_scheduled_hook');


add_action('rest_api_init', function () {
    register_rest_route('wcag/v2', '/detect-changes', [
        'methods'  => 'POST',
        'callback' => 'wcag_detect_file_changes',
        'permission_callback' => '__return_true',
        'timeout' => 120,
    ]);

    register_rest_route('wcag/v2', '/schedule', [
        'methods'  => 'POST',
        'callback' => 'wcag_manage_schedule',
        'permission_callback' => '__return_true',
        'timeout' => 120,
    ]);
});

function wcag_manage_schedule(WP_REST_Request $request){
    $params = $request->get_json_params();
    if(isset($params["action"])){
        if($params["action"] == "start"){
            if ( ! wp_next_scheduled( 'compliance_scheduled_hook' ) ) {
                wp_schedule_event( time(), 'hourly', 'compliance_scheduled_hook' );
                return new WP_REST_Response([
                    'success' => true,
                    'status'  => 'start-schedule',
                ]);
            }else{
                return new WP_REST_Response([
                    'success' => true,
                    'status'  => 'schedule-found',
                ]);
            }
        }
        elseif($params["action"] == "stop"){
            wp_clear_scheduled_hook( 'compliance_scheduled_hook' );
            return new WP_REST_Response([
                'success' => true,
                'status'  => 'stop-schedule',
            ]);
        }
        elseif($params["action"] == "run"){  
            do_action('compliance_scheduled_hook');
            return new WP_REST_Response([
                'success' => true,
                'status'  => 'run-schedule',
            ]);
        }
        elseif($params["action"] == "status"){  
            if (doing_action('compliance_scheduled_hook')) {
                return new WP_REST_Response([
                    'success' => true,
                    'status'  => 'schedule-running',
                ]);
            }else{
                return new WP_REST_Response([
                    'success' => true,
                    'status'  => 'schedule-not-running',
                ]);
            }
        }
        else{
            return new WP_REST_Response([
                'success' => false,
                'status'  => 'invalid-action',
            ]);
        }
    }else{
        return new WP_REST_Response([
            'success' => false,
            'status'  => 'invalid-request',
        ]);
    }

    return new WP_REST_Response($params);
}

function compliance_scheduled_hook() {
    $domain = parse_url(home_url(), PHP_URL_HOST);
    $payload['token'] = get_option('wcag_token');
    $payload['domain'] = $domain;
    $payload['run_time'] = date('Y-m-d H:i:s');

    $ignore_list = get_option('compliance_ignore_list') ?: [];
    sort($ignore_list);

    $scan_result = fileScanner(ABSPATH, $ignore_list);
    $old_file_count = get_option('compliance_file_count');
    $old_last_modified = get_option('compliance_last_modified');

    if (!$old_file_count || !$old_last_modified) {
        update_option('compliance_file_count', $scan_result['count']);
        update_option('compliance_last_modified', $scan_result['last_modified']);
        $payload['success'] = true;
        $payload['message'] = 'Files are scanned for the first time';
        $payload['status'] = 'init';
        $payload['ignore_list'] = $ignore_list;
        $payload['count'] = $scan_result['count'];
        $payload['modified_at'] = $scan_result['last_modified'];
    }elseif ( $scan_result['count'] !== (int) $old_file_count || $scan_result['last_modified'] !== $old_last_modified ) {
        update_option('compliance_file_count', $scan_result['count']);
        update_option('compliance_last_modified', $scan_result['last_modified']);
        $payload['success'] = true ;
        $payload['message'] = 'Files are modified';
        $payload['status'] = 'update';
        $payload['ignore_list'] = $ignore_list;
        $payload['count'] = $scan_result['count'];
        $payload['modified_at'] = $scan_result['last_modified'];
    }else{
        $payload['success'] = true ;
        $payload['message'] = 'No changes detected';
        $payload['status'] = 'no-update';
        $payload['ignore_list'] = $ignore_list;
        $payload['count'] = $scan_result['count'];
        $payload['modified_at'] = $scan_result['last_modified'];
    }
    

    $url = trailingslashit(get_option('wcag_server_url')) . 'wp-json/wp/v2/accessibility-auth/debug';

    $args = [
        'body' => json_encode($payload),
        'headers' => ['Content-Type' => 'application/json'],
        'timeout' => 10,
    ];
    wp_remote_post($url, $args);

}

function fileScanner($path, $ignore_list = []) {
    $fileCount = 0;
    $latestModified = 0;

    $iterator = new RecursiveIteratorIterator(
        new RecursiveCallbackFilterIterator(
            new RecursiveDirectoryIterator($path, RecursiveDirectoryIterator::SKIP_DOTS),
            function ($current, $key, $iterator) use ($ignore_list) {
                $currentPath = str_replace('\\', '/', $current->getPathname());
                $relativePath = str_replace(str_replace('\\', '/', ABSPATH), '/', $currentPath);
                foreach ($ignore_list as $ignorePath) {
                    if (strpos($relativePath, $ignorePath) === 0) {
                        return false; 
                    }
                }
                return true; 
            }
        ),
        RecursiveIteratorIterator::LEAVES_ONLY
    );

    foreach ($iterator as $file) {
        if ($file->isFile()) {
            $fileCount++;
            $modifiedTime = $file->getMTime();
            if ($modifiedTime > $latestModified) {
                $latestModified = $modifiedTime;
            }
        }
    }

    return [
        "count" => $fileCount,
        "last_modified" => $latestModified ? date("Y-m-d H:i:s", $latestModified) : null
    ];
}

function wcag_detect_file_changes(WP_REST_Request $request) {
    $params = $request->get_json_params();
    $new_ignore_list = isset($params['ignore_list']) ? $params['ignore_list'] : [];
    $old_ignore_list = get_option('compliance_ignore_list') ?: [];

    $sorted_old = $old_ignore_list;
    $sorted_new = $new_ignore_list;
    sort($sorted_old);
    sort($sorted_new);

    $effective_ignore_list = !empty($new_ignore_list) ? $new_ignore_list : $old_ignore_list;
    $scan_result = fileScanner(ABSPATH, $effective_ignore_list);

    $old_file_count = get_option('compliance_file_count');
    $old_last_modified = get_option('compliance_last_modified');

    if ($sorted_new !== $sorted_old) {
        update_option('compliance_ignore_list', $new_ignore_list);
        update_option('compliance_file_count', $scan_result['count']);
        update_option('compliance_last_modified', $scan_result['last_modified']);

        return new WP_REST_Response([
            'success' => true,
            'message' => 'Ignore list has been updated',
            'status' => 'ignore-list-update',
            'old_ignore_list' => $old_ignore_list,
            'new_ignore_list' => $new_ignore_list,
            'count' => $scan_result['count'],
            'modified_at' => $scan_result['last_modified'],
        ]);
    }
    if (!$old_file_count || !$old_last_modified) {
        update_option('compliance_file_count', $scan_result['count']);
        update_option('compliance_last_modified', $scan_result['last_modified']);
        return new WP_REST_Response([
            'success' => true,
            'message' => 'Files are scanned for the first time',
            'status' => 'init',
            'old_ignore_list' => $old_ignore_list,
            'new_ignore_list' => $effective_ignore_list,
            'count' => $scan_result['count'],
            'modified_at' => $scan_result['last_modified'],
        ]);
    }

    if ( $scan_result['count'] !== (int) $old_file_count || $scan_result['last_modified'] !== $old_last_modified ) {
        update_option('compliance_file_count', $scan_result['count']);
        update_option('compliance_last_modified', $scan_result['last_modified']);
        return new WP_REST_Response([
            'success' => true,
            'message' => 'Files are modified',
            'status' => 'update',
            'old_ignore_list' => $old_ignore_list,
            'new_ignore_list' => $effective_ignore_list,
            'count' => $scan_result['count'],
            'modified_at' => $scan_result['last_modified'],
        ]);
    }
    return new WP_REST_Response([
        'success' => true,
        'message' => 'No changes detected',
        'status' => 'no-update',
        'old_ignore_list' => $old_ignore_list,
        'new_ignore_list' => $effective_ignore_list,
        'count' => $scan_result['count'],
        'modified_at' => $scan_result['last_modified'],
    ]);
}