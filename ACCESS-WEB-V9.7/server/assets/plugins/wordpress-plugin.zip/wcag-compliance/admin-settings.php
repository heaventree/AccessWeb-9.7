<?php

function wcag_token_name() {
    return 'wcag_token';
}

function wcag_server_name() {
    return 'wcag_server_url';
}

function wcag_add_settings_page() {
    add_options_page(
        'WCAG Compliance',
        'WCAG Compliance',
        'manage_options',
        'wcag-compliance',
        'wcag_settings_page_html'
    );
}
add_action('admin_menu', 'wcag_add_settings_page');

function wcag_register_settings() {
    register_setting('wcag_compliance_group', wcag_token_name());
    register_setting('wcag_compliance_group', wcag_server_name());

    add_settings_section('wcag_section', 'Server Configuration', null, 'wcag-compliance');

    add_settings_field(
        'wcag_server_url',
        'Server URL',
        'wcag_server_url_field_html',
        'wcag-compliance',
        'wcag_section'
    );

    add_settings_field(
        'wcag_token',
        'Token',
        'wcag_token_field_html',
        'wcag-compliance',
        'wcag_section'
    );

    add_action('update_option_' . wcag_token_name(), 'wcag_verify_with_server', 10, 2);
}
add_action('admin_init', 'wcag_register_settings');

function wcag_verify_with_server($old_value, $new_value) {
    $server_url = trailingslashit(get_option(wcag_server_name()));
    $verify_url = $server_url . 'wp-json/wp/v2/accessibility-auth/verify';
    $site_url = site_url();
    $response = wp_remote_post($verify_url, [
        'method'    => 'POST',
        'timeout'   => 10,
        'headers'   => ['Content-Type' => 'application/json'],
        'body'      => json_encode([
            'token'    => sanitize_text_field($new_value),
            'site_url' => $site_url,
        ]),
    ]);
}

function wcag_server_url_field_html() {
    $value = esc_attr(get_option(wcag_server_name(), ''));
    echo "<input type='url' name='" . wcag_server_name() . "' value='{$value}' class='regular-text' />";
}

function wcag_token_field_html() {
    $value = esc_attr(get_option(wcag_token_name(), ''));
    echo "<input type='password' name='" . wcag_token_name() . "' value='{$value}' class='regular-text' />";
}

function wcag_settings_page_html() {
    ?>
    <div class="wrap">
        <h1>WCAG Compliance Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('wcag_compliance_group');
            do_settings_sections('wcag-compliance');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}