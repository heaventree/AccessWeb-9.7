<?php
/**
 * Plugin Name: WCAG Compliance
 * Description: Adds a settings page for connecting with your WCAG Compliance server.
 * Version: 1.0
 * Author: Your Name
 */

if (!defined('ABSPATH')) exit;

register_activation_hook(__FILE__, 'remove_compliance_token');
register_deactivation_hook(__FILE__, 'remove_compliance_token');

function remove_compliance_token() {
    delete_option('wcag_token');
    delete_option('wcag_server_url');
    delete_option('compliance_file_count');
    delete_option('compliance_last_modified');
    wp_clear_scheduled_hook( 'compliance_scheduled_hook' );
}

require "admin-settings.php";
require "functions.php";
